IRON TRAIL GMBH – KOSTENLOSE WEBSITE
====================================

Datei: index.html

Die Website ist eine reine HTML/CSS-Seite und kann kostenlos über GitHub Pages veröffentlicht werden.

WICHTIG:
- Die E-Mail-Adresse im Kontaktbereich ist derzeit info@irontrail.at als Platzhalter.
- Impressum und Datenschutz müssen vor einer geschäftlichen Veröffentlichung mit den tatsächlichen Unternehmensdaten ergänzt werden.
- Eigene Produktfotos und das finale Logo können später eingebaut werden.

GitHub Pages:
1. Auf github.com ein Konto erstellen/anmelden.
2. Neues Repository anlegen, z.B. iron-trail-website.
3. index.html hochladen.
4. Repository Settings → Pages → Deploy from branch → main → /root.
5. Speichern.
6. GitHub stellt danach eine kostenlose .github.io-Adresse bereit.
